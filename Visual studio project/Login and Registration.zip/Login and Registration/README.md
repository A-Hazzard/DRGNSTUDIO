<h2> Author: iReplayz. <img src="https://github.com/KaduFloresta/KaduFloresta/blob/main/img/Hi.gif?raw=true" width="25"></h2>

 <br>
 
<h3>:octocat: GitHub!</h3>
 <code><a href="https://github.com/iReplayz" title="HomeGit">🏠 - Home</a><br></code><br>
 <code><a href="https://github.com/iReplayz?tab=repositories" title="RepoGit">📂 - Repositories</a><br></code>
 
<br>

---

# CSharp - Simple Login Register Form using MySQL

Just a simple Login Form
- MySQL Databse.
- Login Form.
- Register Form.
- Main page.

## Instruction# 

1. Download and open in Visual Studio
    
2. Add Simple-CSharp-LoignForm\Simple Login FORM\MySQL dll\MySql.Data.dll reference
 
3. Setup your MySQL DATABASE.

* Change on:
    - Login Form line: 17.
	- Register Form line: 16
    
4. ENJOY
    