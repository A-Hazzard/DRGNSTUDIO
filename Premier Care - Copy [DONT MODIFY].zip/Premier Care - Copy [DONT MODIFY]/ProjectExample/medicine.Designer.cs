﻿namespace ProjectExample
{
    partial class medicine
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(medicine));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.num2Input = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.feeInput = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.drugIntakeInput = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.showPatients = new System.Windows.Forms.DataGridView();
            this.num1Input = new System.Windows.Forms.TextBox();
            this.showDrugs = new System.Windows.Forms.DataGridView();
            this.drugInput = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.DrugsText = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.patientIDInput = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.nameInput = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.showPatients)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.showDrugs)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.PaleVioletRed;
            this.groupBox1.Controls.Add(this.button4);
            this.groupBox1.Controls.Add(this.button3);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.num2Input);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.feeInput);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.drugIntakeInput);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.showPatients);
            this.groupBox1.Controls.Add(this.num1Input);
            this.groupBox1.Controls.Add(this.showDrugs);
            this.groupBox1.Controls.Add(this.drugInput);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.DrugsText);
            this.groupBox1.Controls.Add(this.button2);
            this.groupBox1.Controls.Add(this.patientIDInput);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.nameInput);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox1.Size = new System.Drawing.Size(849, 522);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.PaleVioletRed;
            this.button4.Font = new System.Drawing.Font("Yu Gothic UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(556, 23);
            this.button4.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(152, 35);
            this.button4.TabIndex = 25;
            this.button4.Text = "Treatment History";
            this.button4.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.PaleVioletRed;
            this.button3.Font = new System.Drawing.Font("Yu Gothic UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(663, 292);
            this.button3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(126, 44);
            this.button3.TabIndex = 24;
            this.button3.Text = "Add Prices";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Yu Gothic UI", 15.25F);
            this.label7.Location = new System.Drawing.Point(485, 345);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(149, 30);
            this.label7.TabIndex = 23;
            this.label7.Text = "List of Patients";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Yu Gothic UI", 15.25F);
            this.label6.Location = new System.Drawing.Point(74, 345);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(130, 30);
            this.label6.TabIndex = 22;
            this.label6.Text = "List of Drugs";
            // 
            // num2Input
            // 
            this.num2Input.Font = new System.Drawing.Font("Mongolian Baiti", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.num2Input.Location = new System.Drawing.Point(613, 266);
            this.num2Input.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.num2Input.Name = "num2Input";
            this.num2Input.Size = new System.Drawing.Size(228, 24);
            this.num2Input.TabIndex = 21;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(608, 147);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(155, 25);
            this.label8.TabIndex = 20;
            this.label8.Text = "Enter cost a drug";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(608, 225);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(211, 25);
            this.label9.TabIndex = 20;
            this.label9.Text = "Enter cost another drug";
            // 
            // feeInput
            // 
            this.feeInput.Font = new System.Drawing.Font("Mongolian Baiti", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.feeInput.Location = new System.Drawing.Point(314, 266);
            this.feeInput.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.feeInput.Name = "feeInput";
            this.feeInput.Size = new System.Drawing.Size(228, 24);
            this.feeInput.TabIndex = 21;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(264, 266);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 25);
            this.label5.TabIndex = 20;
            this.label5.Text = "Fee:";
            // 
            // drugIntakeInput
            // 
            this.drugIntakeInput.Font = new System.Drawing.Font("Mongolian Baiti", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.drugIntakeInput.Location = new System.Drawing.Point(314, 225);
            this.drugIntakeInput.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.drugIntakeInput.Name = "drugIntakeInput";
            this.drugIntakeInput.Size = new System.Drawing.Size(228, 24);
            this.drugIntakeInput.TabIndex = 19;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(202, 225);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(114, 25);
            this.label4.TabIndex = 18;
            this.label4.Text = "Daily Intake:";
            // 
            // showPatients
            // 
            this.showPatients.BackgroundColor = System.Drawing.Color.PaleVioletRed;
            this.showPatients.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.showPatients.ColumnHeadersHeight = 29;
            this.showPatients.Location = new System.Drawing.Point(490, 377);
            this.showPatients.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.showPatients.Name = "showPatients";
            this.showPatients.RowHeadersWidth = 51;
            this.showPatients.RowTemplate.Height = 24;
            this.showPatients.Size = new System.Drawing.Size(336, 119);
            this.showPatients.TabIndex = 17;
            this.showPatients.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.showPatients_CellContentClick);
            // 
            // num1Input
            // 
            this.num1Input.Font = new System.Drawing.Font("Mongolian Baiti", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.num1Input.Location = new System.Drawing.Point(613, 191);
            this.num1Input.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.num1Input.Name = "num1Input";
            this.num1Input.Size = new System.Drawing.Size(228, 24);
            this.num1Input.TabIndex = 15;
            // 
            // showDrugs
            // 
            this.showDrugs.BackgroundColor = System.Drawing.Color.PaleVioletRed;
            this.showDrugs.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.showDrugs.ColumnHeadersHeight = 29;
            this.showDrugs.Location = new System.Drawing.Point(79, 377);
            this.showDrugs.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.showDrugs.Name = "showDrugs";
            this.showDrugs.RowHeadersWidth = 51;
            this.showDrugs.RowTemplate.Height = 24;
            this.showDrugs.Size = new System.Drawing.Size(227, 119);
            this.showDrugs.TabIndex = 16;
            this.showDrugs.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.showDrugs_CellContentClick);
            // 
            // drugInput
            // 
            this.drugInput.Font = new System.Drawing.Font("Mongolian Baiti", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.drugInput.Location = new System.Drawing.Point(314, 184);
            this.drugInput.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.drugInput.Name = "drugInput";
            this.drugInput.Size = new System.Drawing.Size(228, 24);
            this.drugInput.TabIndex = 15;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(252, 184);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 25);
            this.label3.TabIndex = 14;
            this.label3.Text = "Drug:";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.PaleVioletRed;
            this.button1.Font = new System.Drawing.Font("Yu Gothic UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(724, 23);
            this.button1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(74, 35);
            this.button1.TabIndex = 13;
            this.button1.Text = "Home";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // DrugsText
            // 
            this.DrugsText.AutoSize = true;
            this.DrugsText.Font = new System.Drawing.Font("Yu Gothic UI", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DrugsText.Location = new System.Drawing.Point(364, 54);
            this.DrugsText.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.DrugsText.Name = "DrugsText";
            this.DrugsText.Size = new System.Drawing.Size(113, 47);
            this.DrugsText.TabIndex = 10;
            this.DrugsText.Text = "Drugs";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.PaleVioletRed;
            this.button2.Font = new System.Drawing.Font("Yu Gothic UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(314, 292);
            this.button2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(227, 44);
            this.button2.TabIndex = 2;
            this.button2.Text = "Assign";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // patientIDInput
            // 
            this.patientIDInput.Font = new System.Drawing.Font("Mongolian Baiti", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.patientIDInput.Location = new System.Drawing.Point(314, 150);
            this.patientIDInput.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.patientIDInput.Name = "patientIDInput";
            this.patientIDInput.Size = new System.Drawing.Size(228, 24);
            this.patientIDInput.TabIndex = 7;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(214, 147);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(98, 25);
            this.label2.TabIndex = 6;
            this.label2.Text = "Patient ID:";
            // 
            // nameInput
            // 
            this.nameInput.Font = new System.Drawing.Font("Mongolian Baiti", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nameInput.Location = new System.Drawing.Point(314, 117);
            this.nameInput.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.nameInput.Name = "nameInput";
            this.nameInput.Size = new System.Drawing.Size(228, 24);
            this.nameInput.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(183, 117);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(130, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Patient Name:";
            // 
            // medicine
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(849, 522);
            this.Controls.Add(this.groupBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "medicine";
            this.Text = "Medicine";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.showPatients)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.showDrugs)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox drugInput;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label DrugsText;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox patientIDInput;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox nameInput;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView showDrugs;
        private System.Windows.Forms.DataGridView showPatients;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox num2Input;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox feeInput;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox drugIntakeInput;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox num1Input;
        private System.Windows.Forms.Button button4;
    }
}