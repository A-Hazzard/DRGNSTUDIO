select * from USER_SEQUENCES; --Display the different sequences for auto increment features
--DROP CURRENT SEQUENCES TO CREATE NEW ONES
drop sequence pat_num;
drop sequence appId;
drop sequence staffID;
drop sequence nurseID;
drop sequence doctorID;
drop sequence xray_tech_ID;
drop sequence lab_tech_ID;
drop sequence csrID;
drop sequence therapist;
drop sequence csrID;

--CREATE SEQUENCES NEEDED TO AUTO INCREMENT ID NUMBERS
CREATE SEQUENCE pat_num
MINVALUE 1
START WITH 1
INCREMENT BY 1
CACHE 10;


CREATE SEQUENCE appID
MINVALUE 1
START WITH 1
INCREMENT BY 1
CACHE 10;

CREATE SEQUENCE staffID
MINVALUE 1
START WITH 1
INCREMENT BY 1
CACHE 10;

CREATE SEQUENCE nurseID
MINVALUE 1
START WITH 1
INCREMENT BY 1
CACHE 10;

CREATE SEQUENCE xray_tech_ID
MINVALUE 1
START WITH 1
INCREMENT BY 1
CACHE 10;

CREATE SEQUENCE lab_tech_ID
MINVALUE 1
START WITH 1
INCREMENT BY 1
CACHE 10;

CREATE SEQUENCE therapist_ID
MINVALUE 1
START WITH 1
INCREMENT BY 1
CACHE 10;

CREATE SEQUENCE csr_ID
MINVALUE 1
START WITH 1
INCREMENT BY 1
CACHE 10;

CREATE SEQUENCE doctorID
MINVALUE 1
START WITH 1
INCREMENT BY 1
CACHE 10;

--patient Table
drop table patient CASCADE CONSTRAINTS;
CREATE TABLE patient(
    pat_num NUMBER PRIMARY KEY,
    name VARCHAR2(20) NOT NULL,
    phone VARCHAR2(150) NOT NULL,
    DOB VARCHAR2(20) NOT NULL,
    allergies VARCHAR2(100),
    bloodType VARCHAR2(100) NOT NULL,
    password VARCHAR2(50) NOT NULL
);
--ADMIN TABLE
DROP TABLE admin CASCADE CONSTRAINTS;
CREATE TABLE admin(
    email VARCHAR(20) PRIMARY KEY NOT NULL,
    password VARCHAR(8) NOT NULL,
    securitykey VARCHAR(8) NOT NULL,
    adminSecurityKey VARCHAR(8) NOT NULL
);  
--INSERT THESE VALUES FOR LOGIN PAGE
INSERT INTO admin VALUES('care@gmail.com', 'care123', 'VARCHAR2', 'ADMIN123');

DROP TABLE STAFF CASCADE CONSTRAINTS;
CREATE TABLE staff(
    ID NUMBER NOT NULL,
    Name VARCHAR2(30) NOT NULL,
    Email VARCHAR2(50) NOT NULL PRIMARY KEY,
    position VARCHAR2(12) NOT NULL
);

--Appointment Table 
drop table appointment CASCADE CONSTRAINTS;
CREATE TABLE Appointment (
    appID NUMBER PRIMARY KEY,--USED TO TRACK DIFFERENT APPOINTMENTS
    
    --patient information
    pat_num NUMBER NOT NULL,
    pat_name VARCHAR(20) NOT NULL,
    DOB  VARCHAR(20) NOT NULL,
    pat_phone  VARCHAR(10) NOT NULL,
    allergies  VARCHAR(20),
    bloodtype  VARCHAR(20) NOT NULL,
    
    --doctor information
    doc_name  VARCHAR(20) NOT NULL,
    doc_email  VARCHAR(50) NOT NULL,
    doc_position  VARCHAR(20) NOT NULL,
    doc_ID NUMBER NOT NULL,
    time VARCHAR(50) NOT NULL,
    particular VARCHAR(100),
    service VARCHAR(15) NOT NULL,
    fee NUMBER(38) NOT NULL,
    FOREIGN KEY(service) REFERENCES service(serve_type),
    FOREIGN KEY(doc_email) REFERENCES DOCTOR(email)
);
--Doctor Table <<SUB CLASS OF STAFF>>

drop table doctor CASCADE CONSTRAINTS;
CREATE TABLE DOCTOR(
    doctorID NUMBER NOT NULL,
    Name VARCHAR2(30) NOT NULL,
    Email VARCHAR2(50) NOT NULL PRIMARY KEY,
    position VARCHAR2(20) NOT NULL, 
    FOREIGN KEY(email) REFERENCES STAFF(email)
);
--Nurse Table <<SUB CLASS OF STAFF>>
drop table nurse CASCADE CONSTRAINTS;
CREATE TABLE NURSE(
    nurseID NUMBER NOT NULL,
    Name VARCHAR2(30) NOT NULL,
    Email VARCHAR2(50) NOT NULL PRIMARY KEY,
    position VARCHAR2(20) NOT NULL, 
    FOREIGN KEY(email) REFERENCES STAFF(email)
);

drop table lab CASCADE CONSTRAINTS;
CREATE TABLE Lab(
    lab_tech_ID NUMBER NOT NULL,
    Name VARCHAR2(30) NOT NULL,
    Email VARCHAR2(50) NOT NULL PRIMARY KEY,
    position VARCHAR2(20) NOT NULL, 
    FOREIGN KEY(email) REFERENCES STAFF(email)
);
drop table xray CASCADE CONSTRAINTS;
CREATE TABLE XRay(
    xray_tech_ID NUMBER NOT NULL,
    Name VARCHAR2(30) NOT NULL,
    Email VARCHAR2(50) NOT NULL PRIMARY KEY,
    position VARCHAR2(20) NOT NULL, 
    FOREIGN KEY(email) REFERENCES STAFF(email)
);

--Therapist Table <<SUB CLASS OF STAFF>>
drop table therapist CASCADE CONSTRAINTS;
CREATE TABLE Therapist(
    therapist_ID NUMBER NOT NULL,
    Name VARCHAR2(30) NOT NULL,
    Email VARCHAR2(50) NOT NULL PRIMARY KEY,
    position VARCHAR2(20) NOT NULL, 
    FOREIGN KEY(email) REFERENCES STAFF(email)
);

drop table csr CASCADE CONSTRAINTS;
--CSR Table <<SUB CLASS OF STAFF>>
CREATE TABLE CSR(
    csrID NUMBER NOT NULL,
    Name VARCHAR2(30) NOT NULL,
    Email VARCHAR2(50) NOT NULL PRIMARY KEY,
    position VARCHAR2(20) NOT NULL, 
    FOREIGN KEY(email) REFERENCES STAFF(email)
);

drop table drug CASCADE CONSTRAINTS;
--RAUSHAWN CODE
CREATE TABLE DRUG(
    drug VARCHAR(20) PRIMARY KEY NOT NULL,
    COST NUMBER(20) NOT NULL
);
drop table treatment CASCADE CONSTRAINTS;
CREATE TABLE treatment(
    pat_name VARCHAR2(20) NOT NULL,
    pat_id NUMBER NOT NULL,
    drug VARCHAR2(20) NOT NULL,
    dailyIntake NUMBER(6) NOT NULL,
    FEE NUMBER(38) NOT NULL
);
    drop table invoice CASCADE CONSTRAINTS;
    CREATE TABLE invoice(
        pat_name VARCHAR2(20) NOT NULL,
        drug VARCHAR2(20) NOT NULL,
        dailyIntake NUMBER(6) NOT NULL,
        FEE NUMBER(38) NOT NULL,
        FOREIGN KEY (drug) REFERENCES DRUG(drug)
    );
    
--INSERT THESE VALUES TO DISPLAY THE CURRENT DRUGS IN STOCK FOR STAFF MEMBERS WHEN MAKING AN APPOINTMENT
INSERT INTO DRUG VALUES('Panadol', 5);
INSERT INTO DRUG VALUES('Histal', 40);
INSERT INTO DRUG VALUES('Solvin', 35);
INSERT INTO DRUG VALUES('Micro Gynon', 60);
INSERT INTO DRUG VALUES('Gravol', 2);



drop table service CASCADE CONSTRAINTS;
  CREATE TABLE SERVICE(   
    SERVE_TYPE VARCHAR(20) PRIMARY KEY,
    UNITCOST NUMBER(20)
);
    --INSERT THESE VALUES TO DISPLAY THE CURRENT SERVICES FOR STAFF MEMBERS WHEN MAKING AN APPOINTMENT
    INSERT INTO service VALUES('PEDIATRIC', 120); 
    INSERT INTO service VALUES('GENERAL', 90); 
    INSERT INTO service VALUES('SPECIALIST', 400);
    INSERT INTO service VALUES('LABORATORY', 340); 
    INSERT INTO service VALUES('THERAPY', 120);
    INSERT INTO service VALUES('XRAY', 600);
    
  drop table pediatric CASCADE CONSTRAINTS;
        CREATE TABLE PEDIATRIC(
        SERVE_TYPE VARCHAR(20),
        WORKER VARCHAR(20),
        pat_num NUMBER,
        FOREIGN KEY(SERVE_TYPE) REFERENCES SERVICE(SERVE_TYPE),
        FOREIGN KEY(pat_num) REFERENCES patient(pat_num)

        );
        
        drop table general CASCADE CONSTRAINTS;
        CREATE TABLE GENERAL(
        SERVE_TYPE VARCHAR(20),
        WORKER VARCHAR(20),
        pat_num NUMBER,
        FOREIGN KEY(SERVE_TYPE) REFERENCES SERVICE(SERVE_TYPE),
        FOREIGN KEY(pat_num) REFERENCES patient(pat_num)
        
        );
        drop table practice CASCADE CONSTRAINTS;
        CREATE TABLE PRACTICE(
        SERVE_TYPE VARCHAR(20),
        WORKER VARCHAR(20),
        pat_num NUMBER,
        FOREIGN KEY(SERVE_TYPE) REFERENCES SERVICE(SERVE_TYPE),
        FOREIGN KEY(pat_num) REFERENCES patient(pat_num)
        );
        drop table x_ray CASCADE CONSTRAINTS;
        CREATE TABLE X_RAY(
        SERVE_TYPE VARCHAR(20),
        WORKER VARCHAR(20),
        pat_num NUMBER,
        FOREIGN KEY(SERVE_TYPE) REFERENCES SERVICE(SERVE_TYPE),
        FOREIGN KEY(pat_num) REFERENCES patient(pat_num)
        );
        drop table specialist CASCADE CONSTRAINTS;
        CREATE TABLE SPECIALIST(
        SERVE_TYPE VARCHAR(20),
        WORKER VARCHAR(20),
        pat_num NUMBER,
        FOREIGN KEY(SERVE_TYPE) REFERENCES SERVICE(SERVE_TYPE),
        FOREIGN KEY(pat_num) REFERENCES patient(pat_num)
        );
        drop table LABORATORY CASCADE CONSTRAINTS;
        CREATE TABLE LABORATORY(
        SERVE_TYPE VARCHAR(20),
        WORKER VARCHAR(20),
        pat_num NUMBER,
        FOREIGN KEY(SERVE_TYPE) REFERENCES SERVICE(SERVE_TYPE),
        FOREIGN KEY(pat_num) REFERENCES patient(pat_num)
        );
        
        drop table therapy CASCADE CONSTRAINTS;
        CREATE TABLE THERAPY(
        SERVE_TYPE VARCHAR(20),
        WORKER VARCHAR(20),
        pat_num NUMBER,
        FOREIGN KEY(SERVE_TYPE) REFERENCES SERVICE(SERVE_TYPE),
        FOREIGN KEY(pat_num) REFERENCES patient(pat_num)
        );
